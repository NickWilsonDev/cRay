#include <stdio.h>
#include "structs.h"
#include "raytrace.h"
#include "veclib.h"

/*
 * author Nick Wilson and Kao Thao
 * version 3.31.13
 *
 * raytrace.c
 *
 */


/*
 * find_closest_obj - 
 *
 * Parameters: list - pointer to list containing all objects in scene except
 *                    possibly the lights
 *
 *             viewer - location of viewer should be a three dimensional array
 *                      of doubles
 *             unit_dir - unit vector in direction of object
 *             ??       - ?? NULL is passed in the only use of this function
 *             mindist  - this must be the distance between the viewpoint 
 *                        location to the screen
 *
 * Returns:
 *          obj_t - the closest object
 */
//possibly change return type to int?
obj_t find_closest_obj(list_t *list, double *viewer, double *unit_dir, 
                        obj_t *obj, double min_dist) {
    double dist = 0.0;

    obj_t *current = list->first;

    // Check every object in the list
    while(current != NULL) {
        obj_t *temp = (obj_t *) current->priv;
        dist = temp->hits(viewer, unit_dir, obj);

        if (dist != -1) {
            if (min_dist > dist) {
                min_dist = dist;
                obj = current->next;
            }
        }
        current = current->next;
    }
    return current;
}
                        
/*
 * ray_trace - This function traces a single ray and returns the composite
 *             intensity of the light it encounters. It is recursive and so the
 *             start of the ray cannot be assumed to be the viewpoint. 
 *             Recursion will not be involved until we take on specular light.
 *
 * Parameters:  model  - pointer to the model container
 *              base[] - location of viewer, or previous hit(in the recursive
 *                       version)
 *              dir[]  - unit vector in the direction of the object
 *              intensity[] - intensity return location
 *              total_dist - distance ray has traveled so far
 *              last_hit - obj that reflected this ray or NULL
 */
void ray_trace(model_t *model, double base[3], double dir[3], double 
                intensity[3], double total_dist, obj_t *last_hit) {
    //We will call find_closest_object function to find the closest object that
    //is hit, if none are hit then NULL will be returned. The distance from the
    //base of the ray to the nearest hitpoint is returned in mindist.
    
    //viewpoint is supplied from file(stdin)
    obj_t *closest = NULL;
    double mindist = 10.0; //maybe ask about this, set min dist away from viewscreen?

    closest = find_closest_obj(model->scene, base, dir, NULL, mindist);
    
    if (closest == NULL)
        return;

    //add mindist to total_dist
    total_dist = total_dist + mindist;

    //set intensity to the ambient refletivity of closest
    intensity[0] = (closest->material).ambient[0];
    intensity[1] = (closest->material).ambient[1];
    intensity[2] = (closest->material).ambient[2];

    //divide intensity by total_dist
    //
    scale3((1/total_dist), intensity, intensity);
}
