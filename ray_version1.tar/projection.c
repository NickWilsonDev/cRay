#include <stdio.h>
#include <stdlib.h>
#include "projection.h"
#include "malloc.h"

proj_t *projection_init(int argc, char **argv, FILE *in) {
    proj_t *proj = NULL;
    proj = Malloc(sizeof(proj_t));
    char buf[256];

    if (argc != 3) {
        fprintf(stderr, "Usage <executable> <x-window> <y-window>");
        exit(EXIT_FAILURE);
    }
/*    if (atoi(argv[1]) < 0) {
        fprintf(stderr, "x-window : %lf ", argv[1]);
        exit(EXIT_FAILURE);
    }
    if (atoi(argv[2]) < 0) {
      fprintf(stderr, "y-window : %lf ", argv[2]);
      exit(EXIT_FAILURE);
    } */
    proj->win_size_pixel[0] = atoi(argv[1]);
    proj->win_size_pixel[1] = atoi(argv[2]);

    scanf("%lf %lf %lf", &proj->win_size_world[0], &proj->win_size_world[1], &proj->win_size_world[2]);
    fgets(buf, 256, in);
    
    scanf("%lf %lf %lf", &proj->view_point[0], &proj->view_point[1], &proj->view_point[2]);
    fgets(buf, 256, in);

    fgets(buf, 256, in);
    
    return proj;
}

int project_dump(FILE *out, proj_t *proj) {
    fprintf(out, "Scene data - \n");
    fprintf(out, "Window size pixel - \t%d \t%d \n", proj->win_size_pixel[0], proj->win_size_pixel[1]);
    fprintf(out, "Window size world - \t%lf \t%lf \t%lf \n", proj->win_size_world[0], proj->win_size_world[1], proj->win_size_world[2]);
    fprintf(out, "View point - \t%lf \t%lf \t%lf \n\n", proj->view_point[0],  proj->view_point[1], proj->view_point[2]);

    return 0;
}

/*
 * map_pix_to_world - map a pixel coordinate to a world coord
 *
 * Parameters:   proj - pointer to a project definition
 * 				 x, y - x and y pixel coordinates
 * 				 world - pointer to three doubles
 *
 */
void map_pix_to_world(proj_t *proj, int x, int y, double *world) {
	*(world + 0) = (double)x /(proj->win_size_pixel[0] - 1) * 
					proj->win_size_world[0];
	*(world + 0) -= proj->win_size_world[0] / 2.0;

	*(world + 1) = y /(proj->win_size_pixel[1] - 1) *
					proj->win_size_world[1];
	*(world + 2) = 0.0;

}
