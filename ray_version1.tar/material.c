#include <stdio.h>
#include <ctype.h>
#include "structs.h"
#include "ray.h"
#include "material.h"

int material_init(FILE *in, material_t *mat) {
    char buf[256];          //buffer for texts
    int rc = 0;             //boolean for reading (0-success, otherwise=failure)

    rc = (scanf("%lf %lf %lf", &mat->ambient[0], &mat->ambient[1], &mat->ambient[2]) == 3);
    fgets(buf, 256, in);    //consume remaining texts on line

    rc = (scanf("%lf %lf %lf", &mat->diffuse[0], &mat->diffuse[1], &mat->diffuse[2]) == 3);
    fgets(buf, 256, in);    //consume remaining texts on line

    rc = (scanf("%lf %lf %lf", &mat->specular[0], &mat->specular[1], &mat->specular[2]) == 3);
    fgets(buf, 256, in);    //consume remaining texts on line    

    fgets(buf, 256, in);    //consume blank line

    return rc;
}

int material_dump(FILE *out, material_t *mat) { //print formatted listing of datas
    fprintf(out, "Material data - \n");
    fprintf(out, "Ambient  - \t%lf \t%lf \t%lf\n", mat->ambient[0], mat->ambient[1], mat->ambient[2]);
    fprintf(out, "Diffuse  - \t%lf \t%lf \t%lf\n", mat->diffuse[0], mat->diffuse[1], mat->diffuse[2]);
    fprintf(out, "Specular - \t%lf \t%lf \t%lf\n\n", mat->specular[0], mat->specular[1], mat->specular[2]);

    return 0;
}
