#ifndef PLANE_H
#define PLANE_H

#include "structs.h"

obj_t *plane_init(FILE *in, int objtype);

int plane_dump(FILE *out, obj_t *obj);

double hits_plane(double *base, double *dir, obj_t *obj);

#endif
