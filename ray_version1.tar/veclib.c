/**
 * author Nick Wilson and Kao Thao
 * version 3.5.12
 * veclib.c
 *
 * This file will define several functions for performing basic mathimatical
 * operations on vectors. For example addition, subtraction, and dot product.
 * We are assuming that all vectors are three dimensional.
 */

#include <stdio.h>
#include "veclib.h"
#include <math.h>

/**
 * dot3 - Function than computes the dot product of the two vectors passed in 
 * as parameters. Returns a double since mathematically the dot product 
 * produces a scalar and not a vector.
 * parameters
 * *A - pointer to an array that contains components of the first vector
 * *B - pointer to an array that contains components of the second vector
 *
 * return
 * type double - this is the result, it is a double (just a number) rather 
 * than a vector
 */
double dot3(double *A, double *B) {
    double inner_product = 0;
    int i = 0;
    for (; i < 3; i++) {
        inner_product = inner_product + ((A[i]) * (B[i]));
    }
    return inner_product;
}

/**
 * scale3 - Function that multiplies a vector by a scalar. This should result
 * int the resulting vector to appear to have "stretched" or "shrunk" by the 
 * factor represented by the scalefactor parameter.
 * parameters
 * scalefactor - double that is the scalar that the components of the vector
 *                  will be multiplied by
 * *invector   - pointer to an array that stores the components that will be
 *                  "scaled"
 * *outvector  - pointer to an array that will store the components resulting
 *                  from the scaling of the components specified in *invector
 */
void scale3(double scalefactor, double *invector, double *outvector) {
    int i = 0;
    for (; i < 3; i++) {
        outvector[i] = invector[i] * scalefactor;
    }
}

/**
 * length3 - Function finds length or magnitude of vector that was passed in as
 * a parameter.
 * parameter
 * *targetvec - a pointer to an array that contains components of vector that
 *              we wish to find the length of
 */
double length3(double *targetvec) {
    double length;
    length = sqrt(pow(targetvec[0], 2) + pow(targetvec[1], 2) 
                + pow(targetvec[2], 2));
    return length;
}

/**
 * diff3 - Function simply subtracts two vecors and stores the result within a 
 * third. It uses a for loop to traverse through the components of the vectors 
 * and subtracts these components and stores the result in the array pointed
 * to by v3. 
 * parameters
 * *v1 - pointer to an array of components of the first vector
 * *v2 - pointer to an array of components of the second vector
 * *v3 - pointer to an array that will store the components that result from
 *          the subtraction of the other two vectors
 */

void diff3(double *v1, double *v2, double *v3) {
    int i = 0;
    for (; i < 3; i++) {
        v3[i] = v2[i] - v1[i];
    }
}

/**
 * sum - Function simply adds two vecors and stores the result within a third.
 * It uses a for loop to traverse through the components of the vectors and 
 * adds these components together.
 * parameters
 * *v1 - pointer to an array of components of the first vector
 * *v2 - pointer to an array of components of the second vector
 * *v3 - pointer to an array that will store the components that result from
 *          the addition of the other two vectors
 */
void sum(double *v1, double *v2, double *v3) {
    int i = 0;
    for (; i < 3; i++) {
        v3[i] = v2[i] + v1[i];
    }
}

/**
 * unitvec - Function that takes two parameters, both of type double. The first
 * is the vector that we wish to find the "unit vector" of. The second is where
 * we store the components of the unit vector. It uses the formula of the 
 * unitvector = v(x)/length(v1) + v(y)/length(v1) + v(z)/length(v1)
 * params
 * v1 - a pointer to the vector that we will derive the unit vector from
 * v2 - a pointer to a vector that will contain the unit vectors components
 */
void unitvec(double *v1, double *v2) {
    double tempscalar = length3(v1);
    int i = 0;
    for (; i < 3; i++) {
        v2[i] = v1[i] / tempscalar;
    }
}

/**
 * vecprn3 - Function takes two parameters, a character pointer and a double
 * pointer. It prints out the array of characters that the char pointer points
 * too. And uses a for loop to traverse and print the contents of the array
 * that the double pointer points too.
 * params
 * label - a pointer to an array of characters
 * v     - a pointer to an array of doubles, the contents of which make up the
 *          components of the vector
 */
void vecprn3(char *label, double *v) {
    printf("%s\n", label);
    int i = 0;
    for (; i < 3; i++) {
        printf("%f ", v[i]);
    }
    printf("\n");
}
