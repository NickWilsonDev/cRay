#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "sphere.h"
#include "structs.h"
#include "malloc.h"
#include "veclib.h"

obj_t *sphere_init(FILE *in, int objtype) {
    obj_t *obj = NULL;
    sphere_t *sphere = NULL;
//    int pcount = 0;  
    obj = (obj_t*) object_init(in, objtype);  
    sphere = (sphere_t*) Malloc(sizeof(sphere_t));
    obj->priv = sphere;
    char buf[256];

    scanf("%lf %lf %lf", &sphere->center[0], &sphere->center[1], &sphere->center[2]);
    fgets(buf, 256, in); //Consume remaining texts

    scanf("%lf", &sphere->radius);
    fgets(buf, 256, in); //Consume remaining texts
    
    sphere_dump(stderr, obj); //might need an rc variable
     
    return obj; 
}

int sphere_dump(FILE *out, obj_t *obj) {
    sphere_t *sphere = obj->priv;
    int rc; 
    
    fprintf(out, "Dumping object of type Sphere\n");
    rc = material_dump(out, &obj->material); //this func print to stderr
    fprintf(out, "Sphere data \n");
    fprintf(out, "center - \t%lf \t%lf \t%lf\n", sphere->center[0], sphere->center[1], sphere->center[2]);
    fprintf(out, "radius - \t%lf\n\n", sphere->radius);
            
    return rc;
}

double hits_sphere(double *base, double *dir, obj_t *obj) {
    sphere_t *sphere = obj->priv;

    int i;

    double center[3];
    diff3(sphere->center, sphere->center, center);

    double new_base[3];
    diff3(sphere->center, base, new_base);

    double a = dot3(dir, dir);
    if (a == 0.0) {
        fprintf(stderr, "Divide by zero error.");
        exit(EXIT_FAILURE);
    }
    double b = 2 * dot3(new_base, dir);

    double c = dot3(new_base, new_base) - (sphere->radius * sphere->radius);

    double discriminate = (b * b) - (4 * a * c);

    if (discriminate <= 0) { return -1; }

    double th = ((-1 * b) - sqrt(discriminate)) / (2 * a);
    //this part may not be needed for this version of raytracer
    double hitpoint[3];
    scale3(th, dir, hitpoint);

    sum(base, hitpoint, hitpoint);

    for (i = 0; i < 3; i++) {
        obj->hitloc[i] = hitpoint[i];
    }
    ////////////////////////////////////////
    return th;

}
