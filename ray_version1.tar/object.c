#include <stdio.h>
#include "material.h"
#include "structs.h"
#include "object.h"
#include "malloc.h"

obj_t *object_init(FILE *in, int objtype) {
    obj_t*  obj = NULL;    
    static int id;

    obj = (obj_t*) Malloc(sizeof(obj_t));

    obj->next = NULL;
    obj->objtype = objtype;
    obj->objid = ++id;

    if (objtype != LIGHT) {
        material_init(in, &obj->material);
    }

    return obj;
}

int object_dump(FILE *out, obj_t *obj) {
    int rc;
    rc = material_dump(out, &obj->material);
    fprintf(out, "Object Dump - \n");
    fprintf(out, "id: \t%d", obj->objid);
    fprintf(out, "type: \t%d\n", obj->objtype);
    fprintf(out, "normal: \t%lf \t%lf \t%lf \n\n", obj->normal[0], obj->normal[1], obj->normal[2]);
    
    return rc;
}
