#ifndef MALLOC_H
#define MALLOC_H
void* Malloc(size_t size);
#endif
