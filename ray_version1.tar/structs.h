/**
 * author Nick Wilson and Kao Thao
 * version 3.21.13
 * structs.h
 *
 * This header file will contain most of the structs used in the raytracer.
 *
 * ----------------we are allowed to copy these structs into ray.h---------
 */

#ifndef STRUCTS_H
#define STRUCTS_H

typedef struct projection_type {
    int win_size_pixel[2];
    double win_size_world[3];
    double view_point[3];
}proj_t;

typedef struct material_type {
    double ambient[3]; /* Reflectivity for materials */
    double diffuse[3];
    double specular[3];
}material_t;

typedef struct obj_type {
    struct obj_type *next; /* Next object in list */
    int objid; /* Numeric serial # for debug */
    int objtype; /* Type code (14 -> Plane ) */

    /* hits function */
    double (*hits)(double *base, double *dir, struct obj_type *);

    /* Optional plugins for retrieval of reflectivity */
    /* useful for the ever-popular tiled floor */
    void (*getamb)(struct obj_type *, double *);

    /*void (*getdiff)(struct obj_type *, double *);  //Not needed for first ray tracer.
    void (*getspec)(struct obj_type *, double *);*/  //Not needed for first ray tracer.

    /* Reflectivity for reflective objects */
    material_t material;
    
    /* These fields used only in illuminating objects (lights) */
    /*void (*getemiss)(struct obj_type *, double *);  //Not needed for first ray tracer.
    double emissivity[3]; For lights */               //Not needed for first ray tracer.

    void *priv; /* Private type-dependent data */
    
    double hitloc[3]; /* Last hit point */
    double normal[3]; /* Normal at hit point */
} obj_t;

typedef struct list_type {
    obj_t *first;
    obj_t *last;
}list_t;

typedef struct model_type {
    proj_t *proj;
    list_t *lights;
    list_t *scene;
}model_t;

/* Infinite plane */
typedef struct plane_type {
    double point[3]; /* A point on the plane */
    double normal[3]; /* A normal2  vector to the plane */
} plane_t;

/* Sphere */
typedef struct sphere_type {
    double center[3];
    double radius;
} sphere_t;

/* Point light source */
typedef struct light_type {
    double location[3];
} light_t;

#endif
