#include <stdio.h>
#include "structs.h"
#include "image.h"
#include "malloc.h"
#include "projection.h"
#include "veclib.h"
#include "raytrace.h"

/**
 *Author: Nick Wilson & Kao Thao
 *Version: 2.24.13
 * image.c
 */

/*
 * make_image - Function that will print out all information necessary for 
 *              making a ppm image type. This function also calls make_pixel
 *              function for every pixel in the image. Prints the ppm image 
 *              header and then the rgb values for every pixel.
 * Parameter:   model - pointer to type model_t
 */
void make_image(model_t *model) {
    unsigned char *pixmap = NULL;
    // computer size of output image and malloc() pixmap
    int columns = 0;
    int rows    = 0;

    columns = (model->proj)->win_size_pixel[0];
    rows    = (model->proj)->win_size_pixel[1];

    pixmap = (unsigned char*) Malloc( columns * rows 
                                        * sizeof(unsigned char));

    unsigned char *pixmap_location = pixmap;
    
    int x;
    int y;
    for (y = 0; y < rows; y++) {
        for (x = 0; x < columns; x++) {
            make_pixel(model, x, y, pixmap_location);
        }
    }
    // print out header for ppm file
    // will have to change width, height, and max_color to fit variables in
    // params
    printf("P6 %d %d 255\n", columns, rows);
    fwrite(pixmap, sizeof(unsigned char), columns * rows * 3, stdout);


    //write pixmap to stdout--------probably just a for loop that prints out
    // attributes of all pixels one at a time to stdout from pixmap?
}

/*
 * make_pixel -     ??
 * Parameters:      model - ??
 *                  x - pixel x coordinates
 *                  y - pixel y coordinates
 *                  pixval - to (r, g, b) in pixmap
 */
void make_pixel(model_t *model, int x, int y, unsigned char *pixval) {
    double world[3];		//= Malloc(3 * sizeof(double));
    double intensity[3];   //= Malloc(3 * sizeof(double));
    
    map_pix_to_world(model->proj, x, y, world);

    //initialize intensity to (0.0, 0.0, 0.0);
    intensity[0] = 0.0;
    intensity[1] = 0.0;
    intensity[2] = 0.0;

    //compute unit vector dir. in the direction from the view_point to world
    double tempvec[3];
	diff3(model->proj->view_point, world, tempvec);
	unitvec(tempvec, tempvec);

    ray_trace(model, model->proj->view_point, tempvec, intensity, 0.0, NULL);

    //clamp each element of intensity to the range[0.0, 1.0]
    if (intensity[0] > 1) {
        intensity[0] = 1;
    } else if (intensity[0] < 0) {
        intensity[0] = 0;
    }

    if (intensity[1] > 1) {
        intensity[1] = 1;
    } else if (intensity[1] < 0) {
        intensity[1] = 0;
    }
    
    if (intensity[2] > 1) {
        intensity[2] = 1;
    } else if (intensity[2] < 0) {
        intensity[2] = 0;
    }

    //set(r,g,b) components of vector pointed to by pixval to 255 *
    //corresponding intensity
    *pixval = MAX_COLOR * intensity[0];
    *(pixval + 1) = MAX_COLOR * intensity[1];
    *(pixval + 2) = MAX_COLOR * intensity[2];


}
