#include <stdio.h>
#include "plane.h"
#include "structs.h"
#include "malloc.h"
#include "object.h"
#include "veclib.h"

obj_t *plane_init(FILE *in, int objtype) {
    obj_t *obj = NULL;
    plane_t *plane = NULL;

//  int pcount = 0;  

    obj = (obj_t*) object_init(in, objtype);  //temp usage of pcount
    plane = (plane_t*) Malloc(sizeof(plane_t));
    obj->priv = plane;
    char buf[256];

    scanf("%lf %lf %lf", plane->normal[0], plane->normal[1], plane->normal[2]);

    fgets(buf, 256, in); //Consume remaining texts

    scanf("%lf %lf %lf", plane->point[0], plane->point[1], plane->point[2]);
    fgets(buf, 256, in); //Consume remaining texts

    fgets(buf, 256, in); //Consume blank line
    
    plane_dump(stderr, obj); 
    
    return obj;
}

int plane_dump(FILE *out, obj_t *obj) {
    plane_t *plane = obj->priv;
    int rc; 

    fprintf(out, "Dumping object of type Plane\n");
    rc = material_dump(out, &obj->material);//this func print out reflectivities
    fprintf(out, "Plane data -\n");
    fprintf(out, "normal - \t%lf \t%lf \t%lf\n", plane->normal[0], plane->normal[1], plane->normal[2]);
    fprintf(out, "point - \t%lf \t%lf \t%lf\n\n", plane->point[0], plane->point[1], plane->point[2]);

    return rc;
}

double hits_plane(double *base, double *dir, obj_t *obj) {
    plane_t *plane = (plane_t *) obj->priv;

    int i;

    double NdotQ = dot3(plane->normal, plane->point);
    double NdotV = dot3(plane->normal, base);
    double NdotD = dot3(plane->normal, dir);

    if (NdotD == 0.0) { return -1; }

    double th = (NdotQ - NdotV) / (NdotD);

    if (th < 0.0) { return -1; }

    double thD[3];
    scaleN(th, dir, thD);

    double H[3];
    sumN(base, thD, H);

    if (H[2] > 0.0) { return -1; }

    for (i = 0; i < 3; i++) {
        obj->hitloc[i] = H[i];
    }

    return th;
}
