#include <stdio.h>
#include <stdlib.h>
#include "raytrace.h"
#include "model.h"
#include "structs.h"
#include "plane.h"
#include "sphere.h"

int model_init(FILE *in, model_t *model) {
    char buf[256];
    int objtype;
    int rc = 0;
    obj_t *new = NULL;

    while (!(scanf(in, "%d", &objtype))) { //1 is the number of item assigned
        fgets(buf, 256, in);
        switch (objtype) {
            case PLANE:
                new = plane_init(in, objtype);
                break;
            case SPHERE:
                new = sphere_init(in, objtype);
                break;
            default:
                fprintf(stderr, "Error - Bad objectID: %d", objtype);
                exit(EXIT_FAILURE);
    }
    
    if (new == NULL) {
        fprintf(stderr, "Error - Failed to load objectID: %d\n", objtype);
        model_dump(stderr, model);
        exit(EXIT_FAILURE);
    } else {
        list_add(model->scene, new);
    }
    return rc;
}

int model_dump(FILE *out, model_t *model) {
    proj_t *proj = (proj_t*) model->proj;     
    list_t *list = (list_t*) model->scene->first;
    obj_t *temp = NULL;
    fprintf(out, "Model Dump\n");
    projection_dump(out, proj);
    while (list) {
        switch (temp->objtype = list->first->objtype) {
            case PLANE:
                plane_dump(out, temp);
                break;
            case SPHERE:
                sphere_dump(out, temp);
                break;
            default:
                break;
        }
        list->first = temp->next;
    }
    return 0;
}
