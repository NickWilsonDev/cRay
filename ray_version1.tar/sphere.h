#ifndef SPHERE_H
#define SPHERE_H

#include <stdio.h>
#include "structs.h"
#include "ray.h"
#include <ctype.h>
#include "object.h"
#include "material.h"

obj_t *sphere_init(FILE *in, int objtype);

int sphere_dump(FILE *out, obj_t *obj);

double hits_sphere(double *base, double *dir, obj_t *obj);

#endif
