#include <stdio.h>
#include <stdlib.h>
#include "malloc.h"

void* Malloc(size_t size){
    void* mallocPtr;
    mallocPtr = malloc(size);
    if(mallocPtr){
        printf("Not enough memory to be allocated") ;
        exit(1);
    }
    return mallocPtr;
}

